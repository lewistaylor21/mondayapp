const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

// Create deployment directory
const deployDir = path.join(__dirname, 'deploy');
if (!fs.existsSync(deployDir)) {
  fs.mkdirSync(deployDir);
}

// Create the proper Monday.com app structure
const appDir = path.join(deployDir, 'app');
if (!fs.existsSync(appDir)) {
  fs.mkdirSync(appDir);
}

// Copy built files to app directory
const distDir = path.join(__dirname, 'dist');
const files = [
  'index.bundle.js', 
  'index.bundle.js.LICENSE.txt', 
  'index.html',
  'board_view.bundle.js',
  'board_view.bundle.js.LICENSE.txt',
  'board_view.html'
];

files.forEach(file => {
  const source = path.join(distDir, file);
  const dest = path.join(appDir, file);
  if (fs.existsSync(source)) {
    fs.copyFileSync(source, dest);
    console.log(`✅ Copied ${file} to app directory`);
  } else {
    console.log(`⚠️  File not found: ${file}`);
  }
});

// Copy manifest.json to root of deploy directory
const manifestSource = path.join(__dirname, 'manifest.json');
const manifestDest = path.join(deployDir, 'manifest.json');
if (fs.existsSync(manifestSource)) {
  fs.copyFileSync(manifestSource, manifestDest);
  console.log('✅ Copied manifest.json to deploy directory');
}

// Create a proper Monday.com app structure
const mondayAppStructure = {
  'manifest.json': manifestDest,
  'app/index.html': path.join(appDir, 'index.html'),
  'app/index.bundle.js': path.join(appDir, 'index.bundle.js'),
  'app/board_view.html': path.join(appDir, 'board_view.html'),
  'app/board_view.bundle.js': path.join(appDir, 'board_view.bundle.js')
};

// Create zip file with proper structure
const output = fs.createWriteStream(path.join(__dirname, 'deploy.zip'));
const archive = archiver('zip', {
  zlib: { level: 9 } // Sets the compression level
});

output.on('close', () => {
  console.log('✅ Deployment package created: deploy.zip');
  console.log(`📦 Total size: ${(archive.pointer() / 1024 / 1024).toFixed(2)} MB`);
  console.log('📁 App structure:');
  console.log('   ├── manifest.json');
  console.log('   └── app/');
  console.log('       ├── index.html (Dashboard Widget)');
  console.log('       ├── index.bundle.js');
  console.log('       ├── board_view.html (Board View)');
  console.log('       └── board_view.bundle.js');
});

archive.on('error', (err) => {
  throw err;
});

archive.pipe(output);

// Add files with proper structure
archive.file(manifestDest, { name: 'manifest.json' });
archive.file(path.join(appDir, 'index.html'), { name: 'app/index.html' });
archive.file(path.join(appDir, 'index.bundle.js'), { name: 'app/index.bundle.js' });
archive.file(path.join(appDir, 'board_view.html'), { name: 'app/board_view.html' });
archive.file(path.join(appDir, 'board_view.bundle.js'), { name: 'app/board_view.bundle.js' });

archive.finalize();
